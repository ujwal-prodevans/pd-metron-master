export interface IAppConfig {
  apiEndpoint: string;
}
