# Vagrant Deployment

- Codelab Platform
- Fast CAPA Test Platform
- Full Dev Platform
- Quick Dev Platform
