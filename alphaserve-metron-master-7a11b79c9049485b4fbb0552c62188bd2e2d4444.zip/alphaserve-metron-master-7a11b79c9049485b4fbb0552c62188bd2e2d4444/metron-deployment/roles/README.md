# Ansible Roles

- Monit
- OpenTaxii
- Pcap Replay
- Sensor Stubs
- Sensor Test Mode
